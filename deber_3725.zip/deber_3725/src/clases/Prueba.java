
package clases;

/**
 *
 * @author Josue Pillajo
 */
public class Prueba {
    public static void main(String[] args) {
       
        Cubo c1 = new Cubo(3,2,6);
        Cubo c2 = new Cubo();
        Cuadrilatero cu1 = new Cuadrilatero(10);
        c2.CalcularVolumen(0);
        c1.CalcularVolumen(0);
        cu1.AreaPerimetro();
        
    }
    
    
}
